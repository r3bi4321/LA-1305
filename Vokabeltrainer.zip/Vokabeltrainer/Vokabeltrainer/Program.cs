﻿using System;
using System.Collections.Generic;

namespace Vokabeltrainer
{
    class Program
    {
        static void Main(string[] args)
        {
            VokabelTrainer trainer = new VokabelTrainer();
            trainer.HinzufügenVonBenutzer();
            trainer.Start();
        }
    }

    class VokabelTrainer
    {
        private List<Vokabel> vokabeln;
        private List<Vokabel> einmalRichtig;
        private List<Vokabel> zweimalRichtig;

        public VokabelTrainer()
        {
            vokabeln = new List<Vokabel>();
            einmalRichtig = new List<Vokabel>();
            zweimalRichtig = new List<Vokabel>();
        }

        public void HinzufügenVonBenutzer()
        {
            Console.WriteLine("Geben Sie Ihre Vokabeln ein. Geben Sie 'exit' ein, um die Eingabe zu beenden.");
            while (true)
            {
                Console.Write("Deutsches Wort: ");
                string deutsch = Console.ReadLine();
                if (deutsch.ToLower() == "exit")
                    break;

                Console.Write("Fremdsprachiges Wort: ");
                string fremdsprache = Console.ReadLine();
                if (fremdsprache.ToLower() == "exit")
                    break;

                HinzuFügen(deutsch, fremdsprache);
            }
        }

        public void HinzuFügen(string deutsch, string fremdsprache)
        {
            vokabeln.Add(new Vokabel(deutsch, fremdsprache));
        }

        public void Start()
        {
            while (vokabeln.Count > 0 || einmalRichtig.Count > 0)
            {
                TesteVokabeln(vokabeln);
                TesteVokabeln(einmalRichtig);
            }

            Console.WriteLine("Alle Wörter wurden zweimal richtig beantwortet!");
        }

        private void TesteVokabeln(List<Vokabel> liste)
        {
            foreach (var vokabel in new List<Vokabel>(liste))
            {
                Console.Write($"Übersetze '{vokabel.Deutsch}': ");
                string antwort = Console.ReadLine();

                if (antwort.Equals(vokabel.Fremdsprache, StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine("Korrekt!");
                    vokabel.RichtigBeantwortet++;

                    if (vokabel.RichtigBeantwortet == 1)
                    {
                        einmalRichtig.Add(vokabel);
                        liste.Remove(vokabel);
                    }
                    else if (vokabel.RichtigBeantwortet == 2)
                    {
                        zweimalRichtig.Add(vokabel);
                        einmalRichtig.Remove(vokabel);
                    }
                }
                else
                {
                    Console.WriteLine($"Falsch! Die richtige Antwort ist '{vokabel.Fremdsprache}'.");
                }

                // Clear the console after each question
                Console.WriteLine("Drücken Sie eine beliebige Taste, um fortzufahren...");
                Console.ReadKey();
                Console.Clear();
            }
        }
    }

    class Vokabel
    {
        public string Deutsch { get; }
        public string Fremdsprache { get; }
        public int RichtigBeantwortet { get; set; }

        public Vokabel(string deutsch, string fremdsprache)
        {
            Deutsch = deutsch;
            Fremdsprache = fremdsprache;
            RichtigBeantwortet = 0;
        }
    }
}
